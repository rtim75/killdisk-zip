BOOT-DSK.ISO is an ISO image for a bootable CD-ROM containing 
FreeDOS and Active@ Boot Disk utilities:

	Active@ KILLDISK
	Active@	UNERASER
	Active@ Disk Image
	Active@ Password Changer
	Active@ Partition Recovery
	Active@ NTFS Reader


DOS versions of products are located on the bootable partition that is not
visible under Windows environment. Documentation for all products, 
in PDF format, as well as Windows Console versions of Active@ UNERASER and 
Active@ KILLDISK  are located on the partition of the CD-ROM that is 
accessible under Windows. These two products (Console versions) could be 
run from the Windows environment as well.


To prepare the CD-ROM and run Active@ Boot Disk:

- Use any CD/DVD burning software (like Ahead Nero) to burn a CD-ROM ISO image
- Insert this CD-ROM into CD-ROM drive of the computer
- Check that the CD-ROM has boot priority over HDD in BIOS settings
- Re-boot the machine

The computer will boot in DOS mode and the Active@ Boot Disk menu is 
launched at startup.


Good Luck!


Additional product info is on ours web sites:

	www.boot-disk.net
	www.ntfs.com



FREQUENTLY ASKED QUESTIONS:


How can I write ISO files to CD or DVD? 

Many products are posted as ISO-9660 image files. An ISO-9660 image file is 
an exact representation of a CD or DVD, including the content and the 
logical format. The most common use of an image file is to write it to 
a blank CD-R or DVD-R, resulting in an identical copy of the original disc 
including file name and volume label information. ISO image files may also be 
opened and their contents copied to a local folder, much like ZIP files. ISO 
files may also be virtually mounted and accessed as a device. These three 
methods of using ISO images are described below. 

Writing ISO files to CD-R Most CD-R writing software includes a feature to 
create a CD from an image file. Below are instructions for some popular 
applications:


1. Active@ ISO Burner (Freeware)
Active@ ISO Burner is a freeware application that will allow you to burn an 
ISO image file to CD-R, DVD-R, DVD+R, CD-RW, DVD-RW and DVD+RW...

- Download and extract archive http://www.ntfs.com/downloads/Iso-burner.zip
- Insert a blank CD in your CD-RW drive. 
- Run Active@ ISO Burner. 
- Type path to ISO image or click Browse button to locate it in standard dialog. 
- Click [BURN ISO!] button to start process of writing ISO image to CD.



2. ISO Recorder Power Toy 

ISO Recorder is a Windows XP freeware utility that uses native Windows XP 
functions to write images to a CD. You can download this utility from the 
author�s Web page. When the program is installed, it is automatically 
associated with the ISO file extension in Windows Explorer. 
For more information about this utility, visit the author�s Web page at 
	http://isorecorder.alexfeinman.com/isorecorder.htm 

Steps to create a CD if you have installed ISO Recorder Power Toy: 

- Download the ISO CD image to a folder on your computer. 
- Insert a blank CD in your CD-RW drive. 
- Start Windows Explorer. 
- Locate the ISO file, right-click the file name, and then click Copy image 
  to CD to open the ISO Recorder Wizard. 
- Follow the steps in the wizard to write the image to the CD. 

Another alternate method: 

- You can also right-click your CD-R drive and choose Copy Image to CD. 
- In the new window browse to the ISO file and click Next. 

3. Nero - Burning ROM (Ahead Software) 

You can use Nero Burning ROM to record a CD from an ISO file. For more 
information about this program, visit the Ahead Software Web site at: 
	http://www.ahead.de 

Steps to create a CD if you have installed Nero - Burning ROM: 

- Download the ISO CD image to a folder on your computer. 
- Insert a blank CD in your CD-RW drive. 
- Start Nero Burning. 
- Follow the wizard steps to select Data CD creation. 
- When the wizard closes, click Burn Image on the File menu. 
- In the Open dialog box, select the ISO file, and then click Open. 
- In the wizard, click Burn to write the image to the CD. 


4. EasyCD Creator (Roxio) 

You can use EasyCD Creator to create a CD from an ISO file. When the 
program is installed, it is automatically associated with the ISO file 
extension in Windows Explorer. For more information about this program,
visit the Roxio Web site at: http://www.roxio.com 

Steps to create a CD if you have installed EasyCD Creator: 

- Download the ISO CD image to a folder on your computer. 
- Insert a blank CD in your CD-RW drive. 
- Start Windows Explorer. 
- Locate the ISO file, right-click the file name, and then click Open 
  to start EasyCD. 
- In the Write Method section of the CD Creation Setup dialog box, 
  click Disk at Once for optimum recording performance. 
- Click OK to write the image to the CD. 
